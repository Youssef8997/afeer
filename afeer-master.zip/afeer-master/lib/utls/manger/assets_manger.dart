const String imagePath = "assets/image";
const int version = 3;

class AssetsManger {
  static String logo1 = "$imagePath/logo.svg";
  static String logo2 = "$imagePath/afeer.org.png";
  static String onBoarding1 = "$imagePath/onBoarding1.svg";
  static String onBoarding2 = "$imagePath/onBoarding2.svg";
  static String onBoarding3 = "$imagePath/onBoarding3.svg";
  static String faceBookIcon = "$imagePath/faceBook.svg";
  static String googleIcon = "$imagePath/google.svg";
}
